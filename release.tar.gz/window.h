#include <QtGui/QWidget>
#include<QtOpenGL/QGLWidget>
#include <qlineedit.h>
#include <QtGui/QLabel>
#include <qtimer.h>
#include <qpushbutton.h>
#include <qslider.h>

// cantidad de texturas en la base
#define CANT 3

class Window : public QWidget
    {
        Q_OBJECT

    public:
        Window();

    private:	
        QGLWidget *mygldrawer;

        QLabel *labelUsa1;
        QLabel *labelUsa2;
        QLabel *labelUsa3;

        QLabel *labelAmplitud1;
        QLabel *labelAmplitud2;
        QLabel *labelAmplitud3;

        QLabel *labelTurb1;
        QLabel *labelTurb2;
        QLabel *labelTurb3;

        QLabel *labelAngulo1;
        QLabel *labelAngulo2;
        QLabel *labelAngulo3;

        QLabel *labelFrecuencia1;
        QLabel *labelFrecuencia2;
        QLabel *labelFrecuencia3;

        //

        QSlider *amplitudSlider[CANT];
        QSlider *turbSlider[CANT];
        QSlider *anguloSlider[CANT];
        QSlider *frecuenciaSlider[CANT];
        QSlider *intensidadSlider[CANT];

        QPushButton *usaButtons[CANT];

    };
