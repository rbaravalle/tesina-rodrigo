#include<window.h>
#include<QtOpenGL/QGLWidget>
#include<mygldrawer.h>
#include <QtGui/QHBoxLayout>
#include <QtGui/QVBoxLayout>
#include <qslider.h>
#include <QGroupBox>


Window::Window()
{
    mygldrawer = new MyGLDrawer;

    QLabel *labelAmplitud1 = new QLabel(tr("Amplitud 1:"));
    QLabel *labelAmplitud2 = new QLabel(tr("Amplitud 2:"));
    QLabel *labelAmplitud3 = new QLabel(tr("Amplitud 3:"));

    QLabel *labelTurb1 = new QLabel(tr("Turbulencia 1:"));
    QLabel *labelTurb2 = new QLabel(tr("Turbulencia 2:"));
    QLabel *labelTurb3 = new QLabel(tr("Turbulencia 3:"));

    QLabel *labelAngulo1 = new QLabel(tr("Angulo 1:"));
    QLabel *labelAngulo2 = new QLabel(tr("Angulo 2:"));
    QLabel *labelAngulo3 = new QLabel(tr("Angulo 3:"));

    QLabel *labelFrecuencia1 = new QLabel(tr("Frecuencia 1:"));
    QLabel *labelFrecuencia2 = new QLabel(tr("Frecuencia 2:"));
    QLabel *labelFrecuencia3 = new QLabel(tr("Frecuencia 3:"));

    QLabel *labelIntensidad1 = new QLabel(tr("Intensidad 1:"));
    QLabel *labelIntensidad2 = new QLabel(tr("Intensidad 2:"));
    QLabel *labelIntensidad3 = new QLabel(tr("Intensidad 3:"));

    for(int i = 0; i < CANT; i++) {
        turbSlider[i] = new QSlider ();
        turbSlider[i]->setPageStep(1);
        turbSlider[i]->setRange(0,200);
        turbSlider[i]->setValue(1);
        turbSlider[i]->setOrientation(Qt::Horizontal);

        amplitudSlider[i] = new QSlider ();
        amplitudSlider[i]->setPageStep(1);
        amplitudSlider[i]->setRange(0,5000);
        amplitudSlider[i]->setValue(1);
        amplitudSlider[i]->setOrientation(Qt::Horizontal);

        anguloSlider[i] = new QSlider ();
        anguloSlider[i]->setPageStep(1);
        anguloSlider[i]->setRange(0,314);
        anguloSlider[i]->setValue(0);
        anguloSlider[i]->setOrientation(Qt::Horizontal);

        frecuenciaSlider[i] = new QSlider ();
        frecuenciaSlider[i]->setPageStep(1);
        frecuenciaSlider[i]->setRange(0,500);
        frecuenciaSlider[i]->setValue(200);
        frecuenciaSlider[i]->setOrientation(Qt::Horizontal);

        intensidadSlider[i] = new QSlider ();
        intensidadSlider[i]->setPageStep(1);
        intensidadSlider[i]->setRange(0,800);
        intensidadSlider[i]->setValue(100);
        intensidadSlider[i]->setOrientation(Qt::Horizontal);

    }

    usaButtons[0] = new QPushButton(tr("Textura &1"));
    usaButtons[0]->setCheckable(true);
    usaButtons[1] = new QPushButton(tr("Textura &2"));
    usaButtons[1]->setCheckable(true);
    usaButtons[2] = new QPushButton(tr("Textura &3"));
    usaButtons[2]->setCheckable(true);

    QObject::connect(amplitudSlider[0], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarAmplitud1(int)));

    QObject::connect(amplitudSlider[1], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarAmplitud2(int)));

    QObject::connect(amplitudSlider[2], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarAmplitud3(int)));

    QObject::connect(turbSlider[0], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarTurb1(int)));

    QObject::connect(turbSlider[1], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarTurb2(int)));

    QObject::connect(turbSlider[2], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarTurb3(int)));

    QObject::connect(anguloSlider[0], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarAngulo1(int)));

    QObject::connect(anguloSlider[1], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarAngulo2(int)));

    QObject::connect(anguloSlider[2], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarAngulo3(int)));

    QObject::connect(frecuenciaSlider[0], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarFrecuencia1(int)));

    QObject::connect(frecuenciaSlider[1], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarFrecuencia2(int)));

    QObject::connect(frecuenciaSlider[2], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarFrecuencia3(int)));

    QObject::connect( usaButtons[0], SIGNAL(clicked()),
            mygldrawer, SLOT(cambiarUsa1()));

    QObject::connect( usaButtons[1], SIGNAL(clicked()),
            mygldrawer, SLOT(cambiarUsa2()));

    QObject::connect( usaButtons[2], SIGNAL(clicked()),
            mygldrawer, SLOT(cambiarUsa3()));

    QObject::connect(intensidadSlider[0], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarIntensidad1(int)));

    QObject::connect(intensidadSlider[1], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarIntensidad2(int)));

    QObject::connect(intensidadSlider[2], SIGNAL(valueChanged(int)),
            mygldrawer, SLOT(cambiarIntensidad3(int)));



    QHBoxLayout *mainLayout = new QHBoxLayout;
    QVBoxLayout *izqLayout = new QVBoxLayout;

    QVBoxLayout *amplitudLayout = new QVBoxLayout;
    QVBoxLayout *turbLayout = new QVBoxLayout;
    QVBoxLayout *anguloLayout = new QVBoxLayout;
    QVBoxLayout *frecuenciaLayout = new QVBoxLayout;
    QVBoxLayout *usaLayout = new QVBoxLayout;
    QVBoxLayout *intensidadLayout = new QVBoxLayout;

	QGroupBox *usaGroup = new QGroupBox;
	usaGroup->setLayout(usaLayout);
	usaGroup->setTitle(tr("Texturas usadas: "));

	QGroupBox *paramsGroup = new QGroupBox;
	paramsGroup->setLayout(izqLayout);
	paramsGroup->setTitle(tr("Parametros: "));

    setLayout(mainLayout);


	int i;

	i = 0;
    mainLayout->addWidget(paramsGroup,i++);
    mainLayout->addWidget(usaGroup,i++);
    mainLayout->addWidget(mygldrawer,i++);

	i = 0;

	izqLayout->addLayout(intensidadLayout, i++);
    izqLayout->addLayout(amplitudLayout, i++);
    izqLayout->addLayout(turbLayout, i++);
    izqLayout->addLayout(anguloLayout, i++);
    izqLayout->addLayout(frecuenciaLayout, i++);
    izqLayout->addStretch(100);

    i = 0;
    usaLayout->addWidget(usaButtons[0],i++);
    usaLayout->addWidget(usaButtons[1],i++);
    usaLayout->addWidget(usaButtons[2],i++);
    usaLayout->addStretch(100);

	i = 0;
    amplitudLayout->addWidget(labelAmplitud1,i++);
    amplitudLayout->addWidget(amplitudSlider[0],i++);

    amplitudLayout->addWidget(labelAmplitud2,i++);
    amplitudLayout->addWidget(amplitudSlider[1],i++);

    amplitudLayout->addWidget(labelAmplitud3,i++);
    amplitudLayout->addWidget(amplitudSlider[2],i++);
    amplitudLayout->addStretch(100);

    i = 0;
    turbLayout->addWidget(labelTurb1,i++);
    turbLayout->addWidget(turbSlider[0],i++);

    turbLayout->addWidget(labelTurb2,i++);
    turbLayout->addWidget(turbSlider[1],i++);

    turbLayout->addWidget(labelTurb3,i++);
    turbLayout->addWidget(turbSlider[2],i++);
    turbLayout->addStretch(100);

    i = 0;
    anguloLayout->addWidget(labelAngulo1,i++);
    anguloLayout->addWidget(anguloSlider[0],i++);

    anguloLayout->addWidget(labelAngulo2,i++);
    anguloLayout->addWidget(anguloSlider[1],i++);

    anguloLayout->addWidget(labelAngulo3,i++);
    anguloLayout->addWidget(anguloSlider[2],i++);
    anguloLayout->addStretch(100);

    i = 0;
    frecuenciaLayout->addWidget(labelFrecuencia1,i++);
    frecuenciaLayout->addWidget(frecuenciaSlider[0],i++);

    frecuenciaLayout->addWidget(labelFrecuencia2,i++);
    frecuenciaLayout->addWidget(frecuenciaSlider[1],i++);

    frecuenciaLayout->addWidget(labelFrecuencia3,i++);
    frecuenciaLayout->addWidget(frecuenciaSlider[2],i++);

    frecuenciaLayout->addWidget(labelFrecuencia3,i++);
    frecuenciaLayout->addWidget(frecuenciaSlider[2],i++);
    frecuenciaLayout->addStretch(100);

    i = 0;
    intensidadLayout->addWidget(labelIntensidad1,i++);
    intensidadLayout->addWidget(intensidadSlider[0],i++);

    intensidadLayout->addWidget(labelIntensidad2,i++);
    intensidadLayout->addWidget(intensidadSlider[1],i++);

    intensidadLayout->addWidget(labelIntensidad3,i++);
    intensidadLayout->addWidget(intensidadSlider[2],i++);
    intensidadLayout->addStretch(100);

    // para que no minimice la ventana al empezar el programa
    mainLayout->setSizeConstraint(QLayout::SetMinimumSize);

    setWindowTitle(tr("Marmoles - Entrega 1 : 18/12/2009 - Rodrigo Baravalle"));
}

